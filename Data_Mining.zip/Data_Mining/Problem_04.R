# =============================================================================
# PROBLEM 04: SINGLE LINKAGE HIERARCHICAL CLUSTERING (Fully Corrected)
# =============================================================================

cat("=== SINGLE LINKAGE HIERARCHICAL CLUSTERING (11 LANGUAGES) ===\n\n")

# -----------------------------
# Step 1: Distance Matrix
# -----------------------------
lang_names <- c("E","N","Da","Du","G","Fr","Sp","I","P","H","Fi")

lang_dist <- matrix(c(
  0,2,7,6,6,6,7,8,7,5,9,
  2,0,6,6,6,5,7,7,6,5,9,
  7,6,0,6,7,9,9,10,8,8,9,
  6,6,6,0,7,8,7,8,5,5,9,
  6,6,7,7,0,8,7,8,5,5,9,
  6,5,9,8,8,0,5,6,4,4,8,
  7,7,9,7,7,5,0,5,3,4,8,
  8,7,10,8,8,6,5,0,4,4,8,
  7,6,8,5,5,4,3,4,0,3,8,
  5,5,8,5,5,4,4,4,3,0,8,
  9,9,9,9,9,8,8,8,8,8,0
), nrow=11, byrow=TRUE,
dimnames = list(lang_names, lang_names))

d <- as.dist(lang_dist)

# -----------------------------
# Step 2: Hierarchical Clustering
# -----------------------------
hc <- hclust(d, method = "single")

# -----------------------------
# Step 3: Enhanced Dendrogram
# -----------------------------
par(mar=c(6,4,4,2)+0.1, cex.axis=0.9, cex.lab=1, cex.main=1.2, lwd=1.5)

plot(hc, main="Single Linkage Hierarchical Clustering\n11 Languages",
     xlab="Languages", ylab="Distance", hang=-0.1, lwd=2, col="darkblue",
     axes=FALSE, ylim=c(0, max(hc$height)+1))

axis(2, at=seq(0,10,by=2), las=1)
axis(2, at=seq(0,10,by=1), labels=FALSE, tcl=-0.3)

# Horizontal grid lines
abline(h=seq(0,10,by=2), col="gray80", lty=3, lwd=0.7)

# Highlight cluster levels
levels <- c(2,3,4,5)
cols <- c("red","blue","green","purple")
for(i in 1:length(levels)) abline(h=levels[i], col=cols[i], lty=2, lwd=1.5)

# Add cluster rectangles for k=4 clusters
rect.hclust(hc, k = 4, border = "red")

# Add legends
legend("topright", legend=paste("Height =", levels), col=cols, lty=2, lwd=2, cex=0.8, bg="white")
legend("topleft", legend=c("Single Linkage", "11 Languages", "Distance Matrix Given"),
       cex=0.7, bg="white", box.lwd=1)

# -----------------------------
# Step 4: Cluster Analysis at Key Heights
# -----------------------------
analysis_heights <- c(2,3,4,5,6)
cat("\nCLUSTER ANALYSIS AT KEY HEIGHTS\n")
for(h in analysis_heights){
  clusters <- cutree(hc,h=h)
  cat(sprintf("\nHeight %.1f → %d clusters\n", h, length(unique(clusters))))
  for(cl in sort(unique(clusters))){
    members <- lang_names[clusters==cl]
    cat(sprintf("Cluster %d (%d languages): %s\n", cl, length(members), paste(members, collapse=", ")))
  }
}

# -----------------------------
# Step 5: Merge Sequence
# -----------------------------
merge_info <- data.frame(Step=1:length(hc$height), Height=round(hc$height,3),
                         Merge1=hc$merge[,1], Merge2=hc$merge[,2])

# Corrected function for cluster names
get_names <- function(x) {
  if (x < 0) {
    lang_names[abs(x)]  # Use abs() for singleton languages
  } else {
    paste0("C", x)      # Previously merged cluster
  }
}

merge_info$Cluster1 <- sapply(merge_info$Merge1, get_names)
merge_info$Cluster2 <- sapply(merge_info$Merge2, get_names)

cat("\nMERGE SEQUENCE:\n")
print(merge_info[,c("Step","Height","Cluster1","Cluster2")], row.names=FALSE)

# -----------------------------
# Step 6: Summary
# -----------------------------
cat("\nFinal Summary:\n")
cat("✓ Distance matrix processed\n")
cat("✓ Single linkage clustering done\n")
cat("✓ Dendrogram with cluster levels plotted\n")
cat("✓ Merge sequence displayed\n")
cat("✓ Base R only\n")
