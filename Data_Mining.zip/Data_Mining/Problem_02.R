# =============================================================================
# PROBLEM 02: ID3 ALGORITHM 
# =============================================================================

cat("=== ID3 ALGORITHM: FIND BEST SPLITTING ATTRIBUTE ===\n\n")

# -----------------------------
# Step 1: Create dataset
# -----------------------------
data <- data.frame(
  RID = 1:14,
  age = c("youth", "youth", "middle_aged", "senior", "senior", "senior", "middle_aged", 
          "youth", "youth", "senior", "youth", "middle_aged", "middle_aged", "senior"),
  income = c("high", "high", "high", "medium", "low", "low", "low", "medium", "low", 
             "medium", "medium", "medium", "high", "medium"),
  student = c("no", "no", "no", "no", "yes", "yes", "yes", "no", "yes", "yes", "yes", "no", "yes", "no"),
  credit_rating = c("fair", "excellent", "fair", "fair", "fair", "excellent", "excellent", 
                    "fair", "fair", "fair", "excellent", "excellent", "fair", "excellent"),
  buys_computer = c("no", "no", "yes", "yes", "yes", "no", "yes", "no", "yes", "yes", "yes", "yes", "yes", "no")
)

# -----------------------------
# Step 2: Define entropy function
# -----------------------------
entropy <- function(y){
  probs <- table(y)/length(y)
  -sum(probs * log2(probs))
}

# -----------------------------
# Step 3: Compute Information Gain
# -----------------------------
information_gain <- function(data, attribute, target="buys_computer"){
  total_entropy <- entropy(data[[target]])
  
  # Values of attribute
  vals <- unique(data[[attribute]])
  
  weighted_entropy <- 0
  for(v in vals){
    subset <- data[data[[attribute]] == v, ]
    weighted_entropy <- weighted_entropy + (nrow(subset)/nrow(data)) * entropy(subset[[target]])
  }
  
  gain <- total_entropy - weighted_entropy
  return(gain)
}

# -----------------------------
# Step 4: Compute gain for all attributes
# -----------------------------
attributes <- c("age", "income", "student", "credit_rating")
gains <- sapply(attributes, function(attr) information_gain(data, attr))

cat("Information Gain for each attribute:\n")
print(round(gains,3))
cat("\n")

# -----------------------------
# Step 5: Find best splitting attribute
# -----------------------------
best_attr <- names(which.max(gains))
cat("Best splitting attribute (highest information gain):", best_attr, "\n")
