# =========================================================
# Problem 05: Relationship between items A and B
# ---------------------------------------------------------
# Given:
#   Support(A,B) = 0.25
#   Confidence(A → B) = 0.80 = P(B|A)
#   P(B) = 0.60
#
# Objectives:
#   1. Compute P(A)
#   2. Compute Lift, Leverage, Conviction
#   3. Visualize the results clearly
# =========================================================


# ---------------------- Given Values ---------------------
support_AB <- 0.25        # P(A and B)
conf_A_given_B <- 0.80    # P(B | A)
prob_B <- 0.60            # P(B)


# ------------------ Step 1: Compute P(A) ------------------
# Formula: P(A,B) = P(A) * P(B|A)
prob_A <- support_AB / conf_A_given_B
# Example: 0.25 / 0.80 = 0.3125


# ----------------- Step 2: Quality Measures ---------------
# Lift measures how much more likely B occurs when A occurs
lift_val <- conf_A_given_B / prob_B

# Leverage measures the difference from independence
leverage_val <- support_AB - (prob_A * prob_B)

# Conviction measures how often A occurs without B
conviction_val <- (1 - prob_B) / (1 - conf_A_given_B)


# ----------------- Step 3: Print Results ------------------
cat("=== Association Rule Results ===\n")
cat(sprintf("Support P(A,B)      : %.4f\n", support_AB))
cat(sprintf("Confidence P(B|A)   : %.4f\n", conf_A_given_B))
cat(sprintf("P(B)                : %.4f\n", prob_B))
cat(sprintf("Derived P(A)        : %.4f\n", prob_A))
cat("\n--- Quality Measures ---\n")
cat(sprintf("Lift                : %.4f\n", lift_val))
cat(sprintf("Leverage            : %.4f\n", leverage_val))
cat(sprintf("Conviction          : %.4f\n", conviction_val))


# ---------------------- Step 4: Table ---------------------
results <- data.frame(
  Measure = c("Support", "Confidence", "P(B)", "P(A)", 
              "Lift", "Leverage", "Conviction"),
  Value = c(support_AB, conf_A_given_B, prob_B, prob_A, 
            lift_val, leverage_val, conviction_val)
)
print(results, row.names = FALSE)


# ----------------- Step 5: Visualization ------------------
# All values in one vector
vals <- c(
  support_AB,
  conf_A_given_B,
  prob_B,
  prob_A,
  lift_val,
  leverage_val,
  conviction_val
)

# Short, clean labels 
short_labels <- c("Supp", "Conf", "P(B)", "P(A)", "Lift", "Lev", "Conv")

par(mar = c(6, 4, 4, 2))

max_val <- max(vals)
bp <- barplot(vals,
              names.arg = short_labels,
              main = "Association Rule Measures (A → B)",
              ylab = "Value",
              col = "skyblue",
              las = 2,
              ylim = c(0, max_val * 1.25)) 

text(bp,
     vals + (max_val * 0.05),        
     labels = round(vals, 3),
     cex = 0.85)
# =========================================================
# End of script
# =========================================================
