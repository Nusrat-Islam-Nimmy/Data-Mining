# =============================================================================
# PROBLEM 01: BAYESIAN CLASSIFICATION OF HEIGHT (FINAL CORRECTED)
# =============================================================================

cat("=== BAYESIAN CLASSIFICATION: HEIGHT DATA ===\n\n")

# -----------------------------
# Step 1: Create dataset
# -----------------------------
data <- data.frame(
  Name = c("Kristina", "Jim", "Maggie", "Martha", "Stephanie", "Bob", "Kathy", 
           "Dave", "Worth", "Steven", "Debbie", "Todd", "Kim", "Amy", "Wynette"),
  Gender = c("F", "M", "F", "F", "F", "M", "F", "M", "M", "M", "F", "M", "F", "F", "F"),
  Height = c(1.6, 2.0, 1.9, 1.88, 1.7, 1.85, 1.6, 1.7, 2.2, 2.1, 1.8, 1.95, 1.9, 1.8, 1.75),
  Output = c("Short", "Tall", "Medium", "Medium", "Short", "Medium", "Short", 
             "Short", "Tall", "Tall", "Medium", "Medium", "Medium", "Medium", "Medium")
)

# -----------------------------
# Step 2: Bin the height attribute
# -----------------------------
breaks <- c(0, 1.6, 1.7, 1.8, 1.9, 2.0, Inf)
labels <- c("[0,1.6]", "(1.6,1.7]", "(1.7,1.8]", "(1.8,1.9]", "(1.9,2.0]", "(2.0,∞]")

data$HeightBin <- cut(data$Height, breaks=breaks, labels=labels, right=TRUE)

# -----------------------------
# Step 3: Calculate prior probabilities P(Class)
# -----------------------------
priors <- prop.table(table(data$Output))
cat("Prior Probabilities P(Class):\n")
print(round(priors,3))
cat("\n")

# -----------------------------
# Step 4: Calculate likelihoods with Laplace smoothing
# -----------------------------
classes <- levels(factor(data$Output))
genders <- levels(factor(data$Gender))
heights <- labels

# Initialize tables with Laplace smoothing (count +1)
gender_table <- matrix(1, nrow=length(genders), ncol=length(classes),
                       dimnames=list(genders, classes))
height_table <- matrix(1, nrow=length(heights), ncol=length(classes),
                       dimnames=list(heights, classes))

# Count occurrences and add 1
for(cls in classes){
  gender_counts <- table(data$Gender[data$Output==cls])
  height_counts <- table(data$HeightBin[data$Output==cls])
  
  gender_table[names(gender_counts), cls] <- gender_table[names(gender_counts), cls] + gender_counts
  height_table[names(height_counts), cls] <- height_table[names(height_counts), cls] + height_counts
}

# Convert counts to probabilities
gender_likelihood <- prop.table(gender_table, margin=2)
height_likelihood <- prop.table(height_table, margin=2)

cat("Likelihood P(Gender|Class) with Laplace smoothing:\n")
print(round(gender_likelihood,3))
cat("\n")

cat("Likelihood P(HeightBin|Class) with Laplace smoothing:\n")
print(round(height_likelihood,3))
cat("\n")

# -----------------------------
# Step 5: Classify a new instance
# -----------------------------
test_instance <- list(Name="Jafrin", Gender="F", Height=1.86)
test_height_bin <- cut(test_instance$Height, breaks=breaks, labels=labels, right=TRUE)

# Make sure the factor level exists in table
test_height_bin <- as.character(test_height_bin)

posterior <- numeric(length(classes))
names(posterior) <- classes

for(cls in classes){
  # Handle any missing combination safely
  gender_prob <- gender_likelihood[test_instance$Gender, cls]
  height_prob <- height_likelihood[test_height_bin, cls]
  
  posterior[cls] <- priors[cls] * gender_prob * height_prob
}

cat("Posterior Probabilities P(Class|t):\n")
print(round(posterior,3))
cat("\n")

predicted_class <- names(which.max(posterior))
cat("Predicted Class for", test_instance$Name, "(", test_instance$Gender, ",", test_instance$Height, "m ):", predicted_class, "\n\n")

# -----------------------------
# Step 6: Visualize posterior probabilities
# -----------------------------
# Only plot finite values
finite_post <- posterior[is.finite(posterior)]
barplot(finite_post, col=c("red","green","blue")[1:length(finite_post)],
        main="Posterior Probabilities for Classes",
        ylab="Probability", ylim=c(0,max(finite_post)+0.09))
text(x=1:length(finite_post), y=finite_post+0.05, labels=round(finite_post,3))
