# =============================================================================
# PROBLEM 03: BACKPROPAGATION NEURAL NETWORK CALCULATIONS
# =============================================================================

# Define sigmoid activation function
sigmoid <- function(x) {
  return(1 / (1 + exp(-x)))
}

# Initialize parameters as given in the problem
alpha <- 0.9  # Learning rate

# Input values
x1 <- 1
x2 <- 0  
x3 <- 1

# Initial weights and biases from the table
w14 <- 0.2
w15 <- -0.3
w24 <- 0.4
w25 <- 0.1
w34 <- -0.5
w35 <- 0.2
w46 <- -0.3
w56 <- -0.2
theta4 <- -0.4
theta5 <- 0.2
theta6 <- 0.1

target <- 1  # Class label

cat("=== PROBLEM 03: BACKPROPAGATION CALCULATIONS ===\n")
cat("Input: X = (", x1, ",", x2, ",", x3, ")\n")
cat("Target class label:", target, "\n")
cat("Learning rate α =", alpha, "\n\n")

# =============================================================================
# FORWARD PASS
# =============================================================================

cat("FORWARD PASS:\n")

# Input to Hidden Layer
net4 <- x1*w14 + x2*w24 + x3*w34 + theta4
out4 <- sigmoid(net4)
cat("net4 =", x1, "*", w14, "+", x2, "*", w24, "+", x3, "*", w34, "+", theta4, "=", net4, "\n")
cat("out4 = 1/(1 + e^(-net4)) =", out4, "\n\n")

net5 <- x1*w15 + x2*w25 + x3*w35 + theta5
out5 <- sigmoid(net5)
cat("net5 =", x1, "*", w15, "+", x2, "*", w25, "+", x3, "*", w35, "+", theta5, "=", net5, "\n")
cat("out5 = 1/(1 + e^(-net5)) =", out5, "\n\n")

# Hidden to Output Layer
net6 <- out4*w46 + out5*w56 + theta6
out6 <- sigmoid(net6)
cat("net6 = out4*w46 + out5*w56 + theta6 =", out4, "*", w46, "+", out5, "*", w56, "+", theta6, "=", net6, "\n")
cat("out6 = 1/(1 + e^(-net6)) =", out6, "\n\n")

# =============================================================================
# BACKWARD PASS
# =============================================================================

cat("BACKWARD PASS:\n")

# Output layer error
Err6 <- out6 * (1 - out6) * (target - out6)
cat("Err6 = out6 * (1 - out6) * (target - out6) =", out6, "*", (1-out6), "*", (target-out6), "=", Err6, "\n")

# Hidden layer errors
Err4 <- out4 * (1 - out4) * (Err6 * w46)
cat("Err4 = out4 * (1 - out4) * (Err6 * w46) =", out4, "*", (1-out4), "* (", Err6, "*", w46, ") =", Err4, "\n")

Err5 <- out5 * (1 - out5) * (Err6 * w56)
cat("Err5 = out5 * (1 - out5) * (Err6 * w56) =", out5, "*", (1-out5), "* (", Err6, "*", w56, ") =", Err5, "\n\n")

# =============================================================================
# WEIGHT UPDATES
# =============================================================================

cat("WEIGHT UPDATES:\n")

# Update weights between hidden and output layer
delta_w46 <- alpha * Err6 * out4
w46_new <- w46 + delta_w46
cat("Δw46 = α * Err6 * out4 =", alpha, "*", Err6, "*", out4, "=", delta_w46, "\n")
cat("w46(new) = w46 + Δw46 =", w46, "+", delta_w46, "=", w46_new, "\n")

delta_w56 <- alpha * Err6 * out5
w56_new <- w56 + delta_w56
cat("Δw56 = α * Err6 * out5 =", alpha, "*", Err6, "*", out5, "=", delta_w56, "\n")
cat("w56(new) = w56 + Δw56 =", w56, "+", delta_w56, "=", w56_new, "\n")

# Update bias for output layer
delta_theta6 <- alpha * Err6
theta6_new <- theta6 + delta_theta6
cat("Δθ6 = α * Err6 =", alpha, "*", Err6, "=", delta_theta6, "\n")
cat("θ6(new) = θ6 + Δθ6 =", theta6, "+", delta_theta6, "=", theta6_new, "\n\n")

# Update weights between input and hidden layer
delta_w14 <- alpha * Err4 * x1
w14_new <- w14 + delta_w14
cat("Δw14 = α * Err4 * x1 =", alpha, "*", Err4, "*", x1, "=", delta_w14, "\n")
cat("w14(new) = w14 + Δw14 =", w14, "+", delta_w14, "=", w14_new, "\n")

delta_w15 <- alpha * Err5 * x1
w15_new <- w15 + delta_w15
cat("Δw15 = α * Err5 * x1 =", alpha, "*", Err5, "*", x1, "=", delta_w15, "\n")
cat("w15(new) = w15 + Δw15 =", w15, "+", delta_w15, "=", w15_new, "\n")

delta_w24 <- alpha * Err4 * x2
w24_new <- w24 + delta_w24
cat("Δw24 = α * Err4 * x2 =", alpha, "*", Err4, "*", x2, "=", delta_w24, "\n")
cat("w24(new) = w24 + Δw24 =", w24, "+", delta_w24, "=", w24_new, "\n")

delta_w25 <- alpha * Err5 * x2
w25_new <- w25 + delta_w25
cat("Δw25 = α * Err5 * x2 =", alpha, "*", Err5, "*", x2, "=", delta_w25, "\n")
cat("w25(new) = w25 + Δw25 =", w25, "+", delta_w25, "=", w25_new, "\n")

delta_w34 <- alpha * Err4 * x3
w34_new <- w34 + delta_w34
cat("Δw34 = α * Err4 * x3 =", alpha, "*", Err4, "*", x3, "=", delta_w34, "\n")
cat("w34(new) = w34 + Δw34 =", w34, "+", delta_w34, "=", w34_new, "\n")

delta_w35 <- alpha * Err5 * x3
w35_new <- w35 + delta_w35
cat("Δw35 = α * Err5 * x3 =", alpha, "*", Err5, "*", x3, "=", delta_w35, "\n")
cat("w35(new) = w35 + Δw35 =", w35, "+", delta_w35, "=", w35_new, "\n")

# Update biases for hidden layer
delta_theta4 <- alpha * Err4
theta4_new <- theta4 + delta_theta4
cat("Δθ4 = α * Err4 =", alpha, "*", Err4, "=", delta_theta4, "\n")
cat("θ4(new) = θ4 + Δθ4 =", theta4, "+", delta_theta4, "=", theta4_new, "\n")

delta_theta5 <- alpha * Err5
theta5_new <- theta5 + delta_theta5
cat("Δθ5 = α * Err5 =", alpha, "*", Err5, "=", delta_theta5, "\n")
cat("θ5(new) = θ5 + Δθ5 =", theta5, "+", delta_theta5, "=", theta5_new, "\n\n")

# =============================================================================
# FINAL UPDATED VALUES
# =============================================================================

cat("FINAL UPDATED VALUES:\n")
cat("w14 =", w14_new, "\n")
cat("w15 =", w15_new, "\n")
cat("w24 =", w24_new, "\n")
cat("w25 =", w25_new, "\n")
cat("w34 =", w34_new, "\n")
cat("w35 =", w35_new, "\n")
cat("w46 =", w46_new, "\n")
cat("w56 =", w56_new, "\n")
cat("θ4 =", theta4_new, "\n")
cat("θ5 =", theta5_new, "\n")
cat("θ6 =", theta6_new, "\n\n")

cat("Initial output:", out6, "\n")
cat("Target:", target, "\n")
cat("Error:", target - out6, "\n")

